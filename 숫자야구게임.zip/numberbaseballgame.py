import random
print("서로다른 세자리 숫자를 맞춰라!")
print("같은 숫자가 같은 자리에 있으면 -->>스트라이크!")
print("숫자는 같은데 자리가 다르면 -->> 볼 ")
print("3스트라이크가 되면 게임은 종료하고 몇번만에 맞추었는지를 출력합니다!")
alist = [0,0,0] 
st = 0              #스트라이크값
ba = 0              #볼 값
tr = 0              #시도 횟수

alist[0] = random.randint(1,9) #랜덤숫자 생성
alist[1] = alist[0]#둘다 같게해준다
alist[2] = alist[0]#둘다 같게 해준다
while alist[0] == alist[1] :                          #alist[0]과alist[1]이  같을 경우 
    alist[1] = random.randint(1, 9)            # while문이반복되므로 숫자가 다르면 반복되지 않을것이다.
while alist[0]==alist[2] or alist[1] ==alist[2] : #마찬가지로 세개의 숫자가 모두 달라야
    alist[2]=random.randint(1 ,9)               #while 문이 종료되므로 alist[]는 중복되지않는 3개의 수다


while st<3:  #스트라이크 점수가 3점 미만일때 참임으로 3점이면 while문이 끝남.
    a = int(input("서로다른 세자리수 입력 :")) # 한번에 3자리를 모두 입력
    blist = [0, 0, 0] #blist 선언
    blist[0] = a//100 #blist[0] 값
    blist[1] = a%100//10#blist[1] 값
    blist[2] = a%100%10#blist[2] 값
    st = 0  #스트라이크 점수 초기화
    ba =0 # 볼 점수 초기화
    for i in range(0,3):
        for j in range(0,3):
            if ((alist[i]) ==( blist[j]) )and (i == j): #숫자와 자리 모두 같을경우
                st += 1
          
            elif ((alist[i]) == ( blist[j])) and (i != j): #숫자는 같은데 자리는 다를경우
                ba += 1
    tr += 1 #시도횟수 추가
    print(ba,"볼",st,"스트라이크")
print(tr,"번 만에 성공!!")
input("아무키 입력시 종료됩니다.") #콘솔창 안꺼지게 하는


